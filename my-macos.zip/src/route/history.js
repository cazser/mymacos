import { createWebHashHistory } from "vue-router";
export const history = createWebHashHistory();