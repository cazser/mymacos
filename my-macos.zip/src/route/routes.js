import Terminal from '../Applications/Terminal.vue'
export const routes=[
    {path:'/terminal', component: Terminal},
   
]